install caliper-cli using node 18 
command : npm run install

bind sut using node 16
command : npm run bind

start the test-network and deploy the chaincode
update network.yaml with organization peer user details and connection string path

execute benchmark node 16
command : npm run benchmark



caliper 0.5.0 requires node 18
sut and other dependencies requires node 16

Configuring caliper with existing network : https://hyperledger.github.io/caliper/v0.5.0/fabric-tutorial/tutorials-fabric-existing/

https://hyperledger.github.io/caliper/v0.5.0/bench-config/

https://hyperledger.github.io/caliper/v0.5.0/workload-module/

https://raw.githubusercontent.com/hyperledger/fabric/master/scripts/bootstrap.sh

https://github.com/hyperledger/caliper-benchmarks/blob/main/benchmarks/samples/fabric/fabcar/queryCar.js

fabric binding details
https://hyperledger.github.io/caliper/v0.5.0/fabric-config/new/#binding-with-fabric-24