'use strict';

const {WorkloadModuleBase} = require('@hyperledger/caliper-core');
const Utility = require('./utils');

class TestEMR extends WorkloadModuleBase {
    constructor() {
        super();
        this.utilityObj = new Utility();
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        this.workerIndex = workerIndex;
        this.totalWorkers = totalWorkers;
        this.roundIndex = roundIndex;
        this.roundArguments = roundArguments;
        this.sutAdapter = sutAdapter;
        this.sutContext = sutContext;
    }

    async submitTransaction() {

        let userType = ['hospital', 'laboratory', 'doctor', 'nurse', 'patient'];
        let users = {'hospital': [], 'laboratory': [], 'doctor': [], 'nurse': [], 'patient': []}
        let result = {};
        let typeIndex = this.utilityObj.getRandomArbitrary(0, 4);
        let type = userType.at(typeIndex);
        let name = type + '_' + this.workerIndex + '-' + this.roundIndex+ '-' + this.utilityObj.getRandomArbitrary(0, 100);
        let email = name + '@localhost.com';
        let workId = "";

        if (type === 'doctor' || type === 'nurse') {
            let hospiInd = this.utilityObj.getRandomArbitrary(0, users.hospital.length);
            workId = users['hospital'].at(hospiInd);
        }

        if (workId == undefined) workId = "";

        let res = await this.sutAdapter.sendRequests({
            contractId: this.roundArguments.chaincodeID,
            contractVersion: this.roundArguments.contractVersion,
            contractFunction: this.roundArguments.contractFunction,
            contractArguments: [name, email, type, workId],
            timeout: 60
        });
        users[type].push(email);
        console.log("All Users : " + JSON.stringify(users));
    }

    async cleanupWorkloadModule() {
        // NOOP
    }

}


/**
 * Create a new instance of the workload module.
 * @return {TestEMR}
 */
function createWorkloadModule() {
    return new TestEMR();
}

module.exports.createWorkloadModule = createWorkloadModule;