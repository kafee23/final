class Utility{

    constructor() {
    }
    /*
    * Get random number between a range
    * */
    getRandomArbitrary(min, max){
        return Math.random() * (max - min) + min;
    }
}
module.exports = Utility;