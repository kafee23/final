"use strict";

const express = require("express");
const cors = require("cors");
const app = express();
;
const PORT_PATIENT = 3000;
const ADMIN_PORT = 3001;
const PORT_DOCTOR = 3002;
const PORT_HOSPITAL=3003;
const PORT_LABORATORY = 3004;
const PORT_NURSE = 3005;
const admin = require("./enrollAdmin.js");
const user = require("./registerUser.js");
const query = require("./query.js");
const {getLogger} = require("fabric-network/lib/logger");

async function init() {
    app.use(cors());
    app.use(express.json());

    await connect();

    app.get("/", (req, res) => res.send("Hello World!"));
    
    //laboratory routes
    app.post("/laboratory/addEMR", (req, res) => laboratory_addEMR(req, res));

    // Doctor Routes
    app.post("/doctor/addEMR", (req, res) => doctor_addEMR(req, res));
    app.post("/doctor/getEMR", (req, res) => doctor_getEMR(req, res));

    //nurse routes    
    app.post("/nurse/getEMR", (req, res) => nurse_getEMR(req, res));

    //hospial routes
    app.post("/hospital/grantViewAccess", (req, res) => hospital_grantViewAccess(req, res));
    app.post("/hospital/revokeViewAccess", (req, res) => hospital_revokeViewAccess(req, res));
    app.post("/hospital/grantAddAccess", (req, res) => hospital_grantAddAccess(req, res));
    app.post("/hospital/revokeAddAccess", (req, res) => hospital_revokeAddAccess(req, res));

    // Patient Routes
    app.post("/patient/grantViewAccess", (req, res) => patient_grantViewAccess(req, res));
    app.post("/patient/revokeViewAccess", (req, res) => patient_revokeViewAccess(req, res));
    app.post("/patient/grantAddAccess", (req, res) => patient_grantAddAccess(req, res));
    app.post("/patient/revokeAddAccess", (req, res) => patient_revokeAddAccess(req, res));
    app.post("/patient/getEMR", (req, res) => patient_getEMR(req, res));
    app.post("/patient/viewAllEMR", (req, res) => viewAllEMR(req, res));
    app.post("/patient/viewAllUsersWithAddAccess", (req, res) => viewAllUsersWithAddAccess(req, res));
    app.post("/patient/getGrantedUserForEMR", (req, res) => getGrantedUserForEMR(req, res));

    app.post("/admin/addEntityUser", (req, res) => admin_addEntityUser(req, res));
    app.post("/admin/getAllStatesByProperty",(req, res)=>getAllStatesByProperty(req, res));

    app.listen(PORT_DOCTOR, () => console.log(`Doctor App listening on port ${PORT_DOCTOR}`));
    app.listen(PORT_PATIENT, () => console.log(`Patient App listening on port ${PORT_PATIENT}`));
    app.listen(ADMIN_PORT, () => console.log(`Admin App listening on port ${ADMIN_PORT}`));
    app.listen(PORT_HOSPITAL, () => console.log(`Hospital App listening on port ${PORT_HOSPITAL}`));
    app.listen(PORT_LABORATORY, () => console.log(`Laboratory App listening on port ${PORT_LABORATORY}`));
    app.listen(PORT_NURSE, () => console.log(`Nurse App listening on port ${PORT_NURSE}`));
}

async function connect() {
    const userTypes = ["admin1", "doctor", "patient","nurse","hospital","laboratory"];
    await admin.enrollAdmin("admin");

    // Comment out the following line to prevent registering users after first run
    for (const userType of userTypes) {
        await user.registerUser(userType);
    }
}

// Laboratory add EMR
async function laboratory_addEMR(req, res) {
    try {
        let userType = "laboratory";
        await query.initialize(userType);
        const result = await query.all_addEMR(
            userType,
            req.body.userEmail,
            req.body.adderEmail,
            req.body.emrID,
            req.body.type,
            req.body.content
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error);
        console.error(`error: ${userType}_addEMR: ${error}`);
    }
}

// Doctor add EMR
async function doctor_addEMR(req, res) {
    try {
        let userType = "doctor";
        await query.initialize(userType);
        const result = await query.all_addEMR(
            userType,
            req.body.userEmail,
            req.body.adderEmail,
            req.body.emrID,
            req.body.type,
            req.body.content
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error);
        console.error(`error: ${userType}_addEMR: ${error}`);
    }
}
//Doctor get EMR 
async function doctor_getEMR(req, res) {
    try {
        let userType = "doctor";
        await query.initialize(userType);
        const result = await query.all_getEMR(
            userType,
            req.body.emrID,
            req.body.userEmail
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error.toString());
        console.error(`error: ${userType}_getEMR: ${error}`);
    }
}

//Nurse get EMR 
async function nurse_getEMR(req, res) {
    try {
        let userType="nurse";
        await query.initialize(userType);
        const result = await query.all_getEMR(
            userType,
            req.body.emrID,
            req.body.userEmail
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error.toString());
        console.error(`error: ${userType}_getEMR: ${error}`);
    }
}

//hospital routes 
async function hospital_grantViewAccess(req, res) {
    try {
        await query.initialize("hospital");
        const result = await query.hospital_grantViewAccess(
            req.body.userEmail,
            req.body.viewerEmail,
            req.body.emrID,
            req.body.authUser
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error);
        console.error(`error: hospital_grantViewAccess: ${error}`);
    }
}

async function hospital_revokeViewAccess(req, res) {
    try {
        await query.initialize("hospital");
        const result = await query.hospital_revokeViewAccess(
            req.body.userEmail,
            req.body.viewerEmail,
            req.body.emrID,
            req.body.authUser
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error);
        console.error(`erroe: hospital_revokeViewAccess: ${error}`);
    }
}

async function hospital_grantAddAccess(req, res) {
    try {
        await query.initialize("hospital");
        const result = await query.hospital_grantAddAccess(
            req.body.userEmail,
            req.body.adderEmail,
            req.body.authUser
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error);
        console.error(`error: hospital_grantAddAccess: ${error}`);
    }
}

async function hospital_revokeAddAccess(req, res) {
    try {
        await query.initialize("hospital");
        const result = await query.hospital_revokeAddAccess(
            req.body.userEmail,
            req.body.adderEmail,
            req.body.authUser
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error);
        console.error(`error: hospital_revokeAddAccess: ${error}`);
    }
}

// Patient Routes
async function patient_grantViewAccess(req, res) {
    try {
        await query.initialize("patient");
        const result = await query.patient_grantViewAccess(
            req.body.userEmail,
            req.body.viewerEmail,
            req.body.emrID
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error);
        console.error(`error: patient_grantViewAccess: ${error}`);
    }
}

async function patient_revokeViewAccess(req, res) {
    try {
        await query.initialize("patient");
        const result = await query.patient_revokeViewAccess(
            req.body.userEmail,
            req.body.viewerEmail,
            req.body.emrID
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error);
        console.error(`erroe: patient_revokeViewAccess: ${error}`);
    }
}

async function patient_grantAddAccess(req, res) {
    try {
        await query.initialize("patient");
        const result = await query.patient_grantAddAccess(
            req.body.userEmail,
            req.body.adderEmail
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error);
        console.error(`error: patient_grantAddAccess: ${error}`);
    }
}

async function patient_revokeAddAccess(req, res) {
    try {
        await query.initialize("patient");
        const result = await query.patient_revokeAddAccess(
            req.body.userEmail,
            req.body.adderEmail
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error);
        console.error(`error: patient_revokeAddAccess: ${error}`);
    }
}

async function patient_getEMR(req, res) {
    try {
        await query.initialize("patient");
        const result = await query.patient_getEMR(
            req.body.emrID,
            req.body.userEmail
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send("Nothing is tough");
        console.error(`error: patient_getEMR: ${error}`);
    }
}

async function viewAllUsersWithAddAccess(req, res) {
    try {
        await query.initialize("patient");
        const result = await query.viewAllUsersWithAddAccess(req.body.userEmail);
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send("Internal server error");
        console.error(`error on getEMRRoute: ${error}`);
    }
}

async function getGrantedUserForEMR(req, res) {
    try {
        await query.initialize("patient");
        const result = await query.getGrantedUserForEMR(
            req.body.emrID,
            req.body.userEmail
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send("Internal server error");
        console.error(`error on getEMRRoute: ${error}`);
    }
}

async function viewAllEMR(req, res) {
    // emrID: emrID,
    // userEmail: userEmail
    try {
        console.log(req.body.userEmail);
        await query.initialize("patient");
        const result = await query.viewAllEMR(req.body.userEmail);
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send("Internal server error");
        console.error(`error on getEMRRoute: ${error}`);
    }
}

// Admin Routes
async function admin_addEntityUser(req, res) {
    try {
        await query.initialize("admin1");
        const result = await query.admin_addEntityUser(
            req.body.name,
            req.body.email,
            req.body.type,
            req.body.workId
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error);
        console.error(`error: admin_addUser: ${error}`);
    }
}
async function getAllStatesByProperty(req, res){
    try {
        await query.initialize("admin1");
        const result = await query.getAllStatesByProperty(
            req.body.key,
            req.body.value
        );
        res.status(200).send(result);
    } catch (error) {
        res.status(500).send(error);
        console.error(`error: getAllStatesByProperty: ${error}`);
    }
}
init();
