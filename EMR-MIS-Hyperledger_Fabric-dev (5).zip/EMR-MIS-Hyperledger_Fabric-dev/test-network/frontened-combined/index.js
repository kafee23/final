// Combined index.js

$(document).ready(function () {

    //hospital
    $("#grantViewBH").click(grantViewAccessH);
    $("#revokeViewBH").click(revokeViewAccessH);
    $("#grantAddBH").click(grantAddAccessH);
    $("#revokeAddBH").click(revokeAddAccessH);

    // Patient
    $("#grantViewB").click(grantViewAccess);
    $("#revokeViewB").click(revokeViewAccess);
    $("#grantAddB").click(grantAddAccess);
    $("#revokeAddB").click(revokeAddAccess);
    $("#viewEMRFPatient").submit(getEMR);

    $("#viewEMRList").submit(viewAllEMR);
    $("#viewAddAccessList1").submit(viewAddAccessList);
    $("#viewUserForEMR").submit(viewAllUserForEMR);

    // Admin
    $("#addUserF").submit(addUser);

    // Doctor / Laboratory / nurse
    $("#addEMRB").click(addEMRAll);
    $("#viewEMRB").click(getEMRAll);
});


// Hospital functions
const grantViewAccessH = function (event) {
    event.preventDefault();

    const formData = $("#viewAccess").serializeArray();
    const authUser = $("#authorizedUser").val();
    const userEmail = formData[0].value;
    const viewerEmail = formData[1].value;
    const emrID = formData[2].value;
    $.ajax({
        url: "http://192.168.0.104:3003/hospital/grantViewAccess",
        method: "POST",
        data: JSON.stringify({
            userEmail: userEmail,
            viewerEmail: viewerEmail,
            emrID: emrID,
            authUser:authUser
        }),
        contentType: "application/json",
        success: function (resData) {
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
            } else {
                swal("Success", resData, "success");
                $("#viewAccess").trigger("reset");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};
const revokeViewAccessH = function (event) {
    event.preventDefault();

    const formData = $("#viewAccess").serializeArray();
    const userEmail = formData[0].value;
    const viewerEmail = formData[1].value;
    const emrID = formData[2].value;
    const authUser = $("#authorizedUser").val();
    console.log(formData);
    $.ajax({
        url: "http://192.168.0.104:3003/hospital/revokeViewAccess",
        method: "POST",
        data: JSON.stringify({
            userEmail: userEmail,
            viewerEmail: viewerEmail,
            emrID: emrID,
            authUser:authUser
        }),
        contentType: "application/json",
        success: function (resData) {
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
            } else {
                swal("Success", resData, "success");
                $("#viewAccess").trigger("reset");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};
const grantAddAccessH = function (event) {
    event.preventDefault();

    const formData = $("#addAccess").serializeArray();
    const userEmail = formData[0].value;
    const adderEmail = formData[1].value;
    const authUser = $("#authorizedUser").val();
    $.ajax({
        url: "http://192.168.0.104:3003/hospital/grantAddAccess",
        method: "POST",
        data: JSON.stringify({
            userEmail: userEmail,
            adderEmail: adderEmail,
            authUser:authUser
        }),
        contentType: "application/json",
        success: function (resData) {
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
            } else {
                swal("Success", resData, "success");
                $("#addAccess").trigger("reset");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};
const revokeAddAccessH = function (event) {
    event.preventDefault();

    const formData = $("#addAccess").serializeArray();
    const userEmail = formData[0].value;
    const adderEmail = formData[1].value;
    const authUser = $("#authorizedUser").val();
    console.log(formData);
    $.ajax({
        url: "http://192.168.0.104:3003/hospital/revokeAddAccess",
        method: "POST",
        data: JSON.stringify({
            userEmail: userEmail,
            adderEmail: adderEmail,
            authUser:authUser
        }),
        contentType: "application/json",
        success: function (resData) {
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
            } else {
                swal("Success", resData, "success");
                $("#addAccess").trigger("reset");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};

// Patient functions
const grantViewAccess = function (event) {
    event.preventDefault();

    const formData = $("#viewAccessF").serializeArray();
    const userEmail = formData[0].value;
    const viewerEmail = formData[1].value;
    const emrID = formData[2].value;
    $.ajax({
        url: "http://192.168.0.104:3000/patient/grantViewAccess",
        method: "POST",
        data: JSON.stringify({
            userEmail: userEmail,
            viewerEmail: viewerEmail,
            emrID: emrID,
        }),
        contentType: "application/json",
        success: function (resData) {
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
            } else {
                swal("Success", resData, "success");
                $("#viewAccessF").trigger("reset");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};

const revokeViewAccess = function (event) {
    event.preventDefault();

    const formData = $("#viewAccessF").serializeArray();
    const userEmail = formData[0].value;
    const viewerEmail = formData[1].value;
    const emrID = formData[2].value;
    console.log(formData);
    $.ajax({
        url: "http://192.168.0.104:3000/patient/revokeViewAccess",
        method: "POST",
        data: JSON.stringify({
            userEmail: userEmail,
            viewerEmail: viewerEmail,
            emrID: emrID,
        }),
        contentType: "application/json",
        success: function (resData) {
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
            } else {
                swal("Success", resData, "success");
                $("#viewAccessF").trigger("reset");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};

const grantAddAccess = function (event) {
    event.preventDefault();

    const formData = $("#addAccessF").serializeArray();
    const userEmail = formData[0].value;
    const adderEmail = formData[1].value;
    $.ajax({
        url: "http://192.168.0.104:3000/patient/grantAddAccess",
        method: "POST",
        data: JSON.stringify({
            userEmail: userEmail,
            adderEmail: adderEmail,
        }),
        contentType: "application/json",
        success: function (resData) {
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
            } else {
                swal("Success", resData, "success");
                $("#addAccessF").trigger("reset");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};

const revokeAddAccess = function (event) {
    event.preventDefault();

    const formData = $("#addAccessF").serializeArray();
    const userEmail = formData[0].value;
    const adderEmail = formData[1].value;
    console.log(formData);
    $.ajax({
        url: "http://192.168.0.104:3000/patient/revokeAddAccess",
        method: "POST",
        data: JSON.stringify({
            userEmail: userEmail,
            adderEmail: adderEmail,
        }),
        contentType: "application/json",
        success: function (resData) {
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
            } else {
                swal("Success", resData, "success");
                $("#addAccessF").trigger("reset");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};

const getEMR = function (event) {
    event.preventDefault();

    const formData = $("#viewEMRFPatient").serializeArray();
    console.log(formData);
    const userEmail = formData[0].value;
    const emrID = formData[1].value;

    $.ajax({
        url: "http://192.168.0.104:3000/patient/getEMR",
        method: "POST",
        data: JSON.stringify({
            userEmail: userEmail,
            emrID: emrID,
        }),
        contentType: "application/json",
        success: function (resData) {
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
                $("#emrdata").css("display", "none");
            } else {
                $("#emrdata").val(resData);
                $("#emrdata").css("display", "inline");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};

const viewAllEMR = function (event) {
    event.preventDefault();
    console.log(" viewAllEMR sending ...");
    const formData = $("#viewEMRList").serializeArray();
    console.log(formData);
    const userEmail = formData[0].value;

    $.ajax({
        url: "http://192.168.0.104:3000/patient/viewAllEMR",
        method: "POST",
        data: JSON.stringify({
            userEmail: userEmail,
        }),
        contentType: "application/json",
        success: function (resData) {
            resData = JSON.parse(resData);
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
            } else {
                createTable(resData, "viewALlEMR");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};

const viewAddAccessList = function (event) {
    event.preventDefault();
    console.log(" viewAddAccessList sending ...");
    const formData = $("#viewAddAccessList1").serializeArray();
    console.log(formData);
    const userEmail = formData[0].value;

    $.ajax({
        url: "http://192.168.0.104:3000/patient/viewAllUsersWithAddAccess",
        method: "POST",
        data: JSON.stringify({
            userEmail: userEmail,
        }),
        contentType: "application/json",
        success: function (resData) {
            resData = JSON.parse(resData);
            console.log(" viewAddAccessList result ::" + resData);
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
                $("#emrdataviewAddAccessListDiv").css("display", "none");
            } else {
                $("#emrdataviewAddAccessListDiv").val(resData);
                $("#emrdataviewAddAccessListDiv").css("display", "inline");
                createTable(resData, "viewAddAccessList");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};

const viewAllUserForEMR = function (event) {
    event.preventDefault();
    console.log(" viewAllUserForEMR sending ...");
    const formData = $("#viewUserForEMR").serializeArray();
    console.log(formData);
    const userEmail = formData[0].value;
    const emrID = formData[1].value;

    $.ajax({
        url: "http://192.168.0.104:3000/patient/getGrantedUserForEMR",
        method: "POST",
        data: JSON.stringify({
            emrID: emrID,
            userEmail: userEmail,
        }),
        contentType: "application/json",
        success: function (resData) {
            resData = JSON.parse(resData);
            console.log(" viewAllUserForEMR result ::" + resData);
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
                $("#emrdataviewUserForEMRDiv").css("display", "none");
            } else {
                $("#emrdataviewUserForEMRDiv").val(resData);
                $("#emrdataviewUserForEMRDiv").css("display", "inline");
                createTable(resData, "viewAllUserForEMR");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};

function createTable(data, type) {
    if (type == "viewALlEMR") {
        var tableBody = document.querySelector("#viewAllEMRList tbody");
    }
    if (type == "viewAddAccessList") {
        var tableBody = document.querySelector("#viewAddAccessList tbody");
    }
    if (type == "viewAllUserForEMR") {
        var tableBody = document.querySelector("#viewAllUserForEMR tbody");
    }

    // Clear existing rows
    tableBody.innerHTML = "";
    console.log(typeof data);

    // Write the above loop in another way
    for (var i = 0; i < data.length; i++) {
        var tableRow = document.createElement("tr");

        for (var j = 0; j < data[i].length; j++) {
            var tableCell = document.createElement("td");
            console.log(data[0]);
            tableCell.textContent = data[i][j];
            tableRow.appendChild(tableCell);
        }

        tableBody.appendChild(tableRow);
    }
}

// Add user by admin
const addUser = function (event) {
    event.preventDefault();

    const formData = $("#addUserF").serializeArray();
    const name = formData[0].value;
    const email = formData[1].value;
    const work = formData[2].value;
    const type = formData[3].value;

    $.ajax({
        url: "http://192.168.0.104:3001/admin/addEntityUser",
        method: "POST",
        data: JSON.stringify({
            name: name,
            email: email,
            type: type,
            workId:work
        }),
        contentType: "application/json",
        success: function (resData) {
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
            } else {
                swal("Success", resData, "success");
                $("#addUserF").trigger("reset");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};

// add emr by doctor or lab
const addEMRAll = function (event) {
    event.preventDefault();
    const host =$('#host').val();
    const port =$('#port').val();
    const formData = $("#addEMR").serializeArray();
    const userEmail = formData[0].value;
    const adderEmail = formData[1].value;
    const emrID = formData[2].value;
    const type = "medical";
    const content = formData[3].value;

    $.ajax({
        url: 'http://192.168.0.104:'+port+'/'+host+'/addEMR',
        method: "POST",
        data: JSON.stringify({
            userEmail: userEmail,
            adderEmail: adderEmail,
            emrID: emrID,
            type: type,
            content: content,
        }),
        contentType: "application/json",
        success: function (resData) {
            if (resData.toString().indexOf("Error:") != -1) {
                swal("Oops", resData, "error");
            } else {
                swal("Success", resData, "success");
                $("#addEMRF").trigger("reset");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};
//view emr by doctor or nurse
const getEMRAll = function (event) {
    event.preventDefault();
    const host =$('#host').val();
    const port =$('#port').val();
    const formData = $("#viewEMR").serializeArray();
    const emrID = formData[0].value;
    const userEmail = formData[1].value;
    $.ajax({
        url: 'http://192.168.0.104:'+port+'/'+host+'/getEMR',
        method: "POST",
        data: JSON.stringify({
            emrID: emrID,
            userEmail: userEmail,
        }),
        contentType: "application/json",
        success: function (resData) {
            if (resData.toString().indexOf("Error:") !== -1) {
                swal("Oops", resData, "error");
                console.log(resData);
                $("#emrdataViewer").css("display", "none");
            } else {
                $("#emrdataViewer").val(resData);
                $("#emrdataViewer").css("display", "inline");
            }
        },
        error: function (error) {
            swal("Oops", error.toString(), "error");
            console.log(error);
        },
    });
};