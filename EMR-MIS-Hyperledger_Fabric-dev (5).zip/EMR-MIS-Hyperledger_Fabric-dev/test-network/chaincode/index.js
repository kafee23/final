'use strict';

const EMR = require('./lib/emrcontract.js');

module.exports.EMR = EMR;
module.exports.contracts = [EMR];
