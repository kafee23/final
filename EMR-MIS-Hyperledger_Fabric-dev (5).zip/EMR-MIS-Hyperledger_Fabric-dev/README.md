# 

## Introduction


## Setup

1. **Clone the repository:**



2. **Install Dependencies:**

   [Click here](https://hyperledger-fabric.readthedocs.io/en/release-2.5/install.html) for installation instruction of Hyperledger fabric runtime binaries. Put the binaries inside ./emr-mis-hf/bin directory.

   Install Dependencies for chaincode : 
   
   ```bash
   cd ./test-network/chaincode && npm install
   ```

   Install Dependencies for backend server application : 
   
   ```bash
   cd ../backend-combined && npm install
   ```

3. **Navigate to the test-network directory:**

   ```bash
      cd ../
   ```

4. **Execute the following commands to set up the network and deploy the chaincode:**

   ```bash
      ./network.sh down
      ./network.sh up createChannel -ca -s couchdb
      ./deploymentScript.sh
   ```

4. **After the execution of the above commands, navigate to the backend-combined directory:**

   ```bash
      cd ./backend-combined
   ```

5. **Enroll admin, register user, and start the application:**

   ```bash
      node enrollAdmin.js
      node registerUser.js
      node app.js
   ```

6. **To view Frontend**

```bash
   cd ../frontend-combined
   Run adminApplication.html
```

** In case face bash script execution permission problem then use following command in repository root: ** 

   ```bash
   chmod +x ./*.sh
   ```
